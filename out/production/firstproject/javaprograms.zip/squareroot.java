
public class squareroot {
    public static void main(String[] args) {
        int number=25;
        System.out.println("Square of "+number+ "is " + squarert(number));

    }
    static double squarert( int x)
    {
        double R = Math.sqrt(x);
        return(R);
    }
}
