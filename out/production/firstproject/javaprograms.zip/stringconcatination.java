public class stringconcatination {
    public static void main(String[] args) {
        String str1="Manpreet";
        String str2=" Singh";
        System.out.println("String after concatination " + Strincon(str1,str2));

    }
    static String Strincon(String x, String y)

    {
        return(x+y);
    }
}
